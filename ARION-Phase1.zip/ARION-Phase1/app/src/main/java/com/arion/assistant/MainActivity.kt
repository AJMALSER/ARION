package com.arion.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.arion.assistant.data.ActivityEvent
import com.arion.assistant.data.ArionDatabase
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF090D16)
private val Panel = Color(0xFF151D2B)
private val Mint = Color(0xFF70E1D1)

class MainActivity : ComponentActivity() {
    private val database by lazy { ArionDatabase.getInstance(this) }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results.filterValues { it }.keys
        lifecycleScope.launch {
            database.activityEventDao().insert(
                ActivityEvent(
                    category = "SYSTEM",
                    title = "Permission request completed",
                    detail = if (granted.isEmpty()) "No requested permissions granted" else "Granted: ${granted.joinToString()}"
                )
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch {
            database.activityEventDao().insert(
                ActivityEvent(category = "SYSTEM", title = "ARION started", detail = "Phase 1 foundation is running")
            )
        }
        setContent {
            val events by database.activityEventDao().observeRecent().collectAsState(initial = emptyList())
            ArionTheme {
                ArionDashboard(
                    events = events,
                    microphoneGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED,
                    onRequestPermissions = { requestCorePermissions() }
                )
            }
        }
    }

    private fun requestCorePermissions() {
        val permissions = buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }

        if (permissions.isEmpty()) {
            lifecycleScope.launch {
                database.activityEventDao().insert(
                    ActivityEvent(category = "SYSTEM", title = "Permissions ready", detail = "Requested Phase 1 permissions are already granted")
                )
            }
        } else {
            permissionLauncher.launch(permissions.toTypedArray())
        }
    }
}

@Composable
private fun ArionTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Mint,
        onPrimary = Ink,
        background = Ink,
        surface = Panel,
        onSurface = Color(0xFFEAF0F8)
    ), content = content)
}

@Composable
private fun ArionDashboard(
    events: List<ActivityEvent>,
    microphoneGranted: Boolean,
    onRequestPermissions: () -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text("ARION", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                        Text("PERSONAL INTELLIGENCE", color = Mint, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Text("PHASE 01", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
            item {
                Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("◉", color = Mint, fontSize = 64.sp)
                        Text("ARION is online", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Text("Foundation mode · Voice engine not activated yet", color = Color(0xFF9AA8BC), fontSize = 12.sp)
                        Spacer(Modifier.height(16.dp))
                        Button(onClick = onRequestPermissions, modifier = Modifier.fillMaxWidth()) {
                            Text("Set up permissions")
                        }
                    }
                }
            }
            item {
                Text("SYSTEM STATUS", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                StatusCard("Microphone permission", if (microphoneGranted) "Granted" else "Not granted", Icons.Default.Mic)
                StatusCard("Local database", "Ready", Icons.Default.Security)
                StatusCard("Phone controller", "Phase 1 · Not connected", Icons.Default.Smartphone)
            }
            item {
                Text("RECENT ACTIVITY", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            }
            if (events.isEmpty()) {
                item { Text("No activity yet.", color = Color(0xFF9AA8BC)) }
            } else {
                items(events, key = { it.id }) { event ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text(event.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text(event.detail, color = Color(0xFF9AA8BC), fontSize = 12.sp)
                            Text(SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(event.createdAt)), color = Mint, fontSize = 10.sp)
                        }
                    }
                }
            }
            item {
                Text("Privacy: Phase 1 stores app activity in a private local database. Encrypted backup is not enabled yet.", color = Color(0xFF9AA8BC), fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun StatusCard(title: String, status: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            androidx.compose.material3.Icon(icon, contentDescription = null, tint = Mint)
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text(status, color = Color(0xFF9AA8BC), fontSize = 11.sp)
            }
        }
    }
}
