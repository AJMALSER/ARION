package com.arion.assistant.data

import android.content.Context
import androidx.room.Database
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "activity_events")
data class ActivityEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,
    val title: String,
    val detail: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface ActivityEventDao {
    @Insert
    suspend fun insert(event: ActivityEvent)

    @Query("SELECT * FROM activity_events ORDER BY createdAt DESC LIMIT 30")
    fun observeRecent(): Flow<List<ActivityEvent>>
}

@Database(entities = [ActivityEvent::class], version = 1, exportSchema = false)
abstract class ArionDatabase : RoomDatabase() {
    abstract fun activityEventDao(): ActivityEventDao

    companion object {
        @Volatile private var INSTANCE: ArionDatabase? = null

        fun getInstance(context: Context): ArionDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ArionDatabase::class.java,
                    "arion-local.db"
                ).build().also { INSTANCE = it }
            }
    }
}
