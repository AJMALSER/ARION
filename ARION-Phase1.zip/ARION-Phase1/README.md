# ARION — Phase 1 Android foundation

Native Kotlin + Jetpack Compose starter for an Android personal assistant. This phase provides the dashboard, app-private Room database, basic permission onboarding, and GitHub Actions debug APK build.

## Important scope boundaries

- This is Phase 1 only. It does **not** yet implement wake-word detection, payment parsing, call monitoring, phone control, AI networking, or cloud backup.
- The microphone permission is requested as a foundation for later voice work; no audio is recorded in this phase.
- Local Room data is app-private but is **not encrypted at rest** in this starter. Do not put sensitive financial or call data into it yet. Database encryption and authenticated encrypted cloud backup must be implemented and tested before those modules store real personal data.
- Always-on wake-word operation is constrained by Android microphone foreground-service rules and Realme battery management. It needs a visible, user-started foreground service, a persistent notification, explicit microphone permission, and device testing. It cannot be promised to run continuously in every state.

## Requirements

- Android Studio/Gradle build environment: JDK 17, Gradle 8.11.1, Android Gradle Plugin 8.9.2.
- Android device: Android 8.0+ (minSdk 26). Target SDK 35.
- Development can be done from a phone using GitHub's mobile website or a browser-based editor. APK compilation happens on GitHub Actions.

## GitHub setup from your Android phone

1. Sign in to GitHub and create a **private** repository named `ARION`.
2. Upload the contents of this folder to the repository root (not the containing `ARION-Phase1` folder).
3. Ensure `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/`, and `.github/` are at the repository root.
4. Open the repository's **Actions** tab. If prompted, enable workflows.
5. Choose **Build ARION APK** → **Run workflow**. You can also trigger a build by pushing a commit to `main`.
6. Open the completed workflow run, scroll to **Artifacts**, and download `ARION-debug-apk`.
7. Extract the ZIP on your phone and install `app-debug.apk`. Allow installation from the browser/file manager when Android asks.

## Project structure

```text
ARION/
├── .github/workflows/android.yml
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/arion/assistant/
│       │   ├── MainActivity.kt
│       │   └── data/ArionDatabase.kt
│       └── res/values/styles.xml
├── build.gradle.kts
├── gradle.properties
├── settings.gradle.kts
└── README.md
```

## Phase 1 permissions

- `RECORD_AUDIO`: requested only when the user taps Set up permissions; not used to record audio in Phase 1.
- `POST_NOTIFICATIONS`: requested on Android 13+; the later foreground voice service will need a visible notification.

No contacts, call-log, SMS, accessibility, location, or notification-listener permissions are requested in Phase 1. Add each only alongside its feature and a clear user-facing explanation.

## Build details

The workflow installs JDK 17 and Gradle 8.11.1, then runs:

```bash
gradle --no-daemon clean assembleDebug
```

The APK is produced at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

The debug application ID is `com.arion.assistant.debug` so a future release build can use `com.arion.assistant` without colliding with the debug install.
